﻿using Library.Service;
using Library.Web.ViewModels;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace Library.Web.Controllers
{
    public class AdminController : Controller
    {
        private readonly IBookService bookService;

        public AdminController(IBookService bookService)
        {
            this.bookService = bookService;
        }

        public ActionResult ListBooks()
        {
            
            IEnumerable<BookViewModel> books = bookService.GetAllBooks()
                .Select(b => new BookViewModel
                {
                    ID = b.ID,
                    Title = b.Title,
                    PublicationDate = b.PublicationDate,
                    Edition = b.Edition,
                    PageNumber = b.PageNumber,
                    TotalCopies = b.TotalCopies,
                    AvailableCopies = b.AvailableCopies,
                    ISBN = b.ISBN,
                    CreateDate = b.CreateDate,
                    ChangeDate = b.ChangeDate,
                    DeleteDate = b.DeleteDate
                });

            return View(books);
        }
    }
}
