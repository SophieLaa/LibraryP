﻿//using Library.Service;
//using Library.Web.ViewModels;
//using System.Security.Cryptography;
//using System.Text;
//using System.Web.Mvc;

//namespace Library.Web.Controllers
//{
//    public class RegisterController : Controller
//    {
//        private readonly IUserService userService;
//        private readonly IRoleService roleService;

//        public RegisterController(IUserService userService, IRoleService roleService)
//        {
//            this.userService = userService;
//            this.roleService = roleService;
//        }

//        [HttpGet]
//        public ActionResult Index()
//        {
//            return View();
//        }

//        [HttpPost]
//        public ActionResult Index(RegisterViewModel model)
//        {
//            if (ModelState.IsValid)
//            {
//                var newUser = new User
//                {
//                    UserName = model.UserName,
//                    Password = GetHashedPassword(model.Password),
//                    RegistrationDate = model.RegistrationDate
//                };

//                var selectedRole = roleService.GetRoleByTitle(model.SelectedRole);

//                if (selectedRole != null)
//                {
//                    newUser.UserRole = selectedRole;
//                }
//                else
//                {
//                    ModelState.AddModelError("SelectedRole", "Invalid role selection.");
//                    return View(model);
//                }

//                userService.RegisterUser(newUser);

//                return RedirectToAction("Index", "Login");
//            }

//            return View(model);
//        }

//        private byte[] GetHashedPassword(string password)
//        {
//            using (var sha256 = SHA256.Create())
//            {
//                byte[] bytes = Encoding.UTF8.GetBytes(password);
//                byte[] hash = sha256.ComputeHash(bytes);
//                return hash;
//            }
//        }
//    }
//}
using Library.Service;
using Library.Web.ViewModels;
using System.Security.Cryptography;
using System.Text;
using System.Web.Mvc;

namespace Library.Web.Controllers
{
    public class RegisterController : Controller
    {
        private readonly IUserService userService;
       // private readonly IRoleService roleService;

        public RegisterController(IUserService userService)
        //, IRoleService roleService
        {
            this.userService = userService;
           // this.roleService = roleService;
        }

        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
              
                if (userService.ValidateUser(model.UserName, model.Password))
                {
                    ModelState.AddModelError("UserName", "User already exists.");
                    return View(model);
                }

                // Create a new User object
                var newUser = new User
                {
                    UserName = model.UserName,
                    Password = model.Password, // No need to hash here, as the service will handle it
                    Email = model.Email,
                    RegistrationDate = model.RegistrationDate
                };

                // You may want to set other properties of the User model here, e.g., IsActive

                // Register the user using the UserService
                userService.RegisterUser(newUser);

                return RedirectToAction("Index", "Login");
            }

            return View(model);
        }


    }
}
