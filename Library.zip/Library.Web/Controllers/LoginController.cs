﻿using Library.Web.Services;
using Library.Web.ViewModels;
using System.Web.Mvc;
using Library.Service;


namespace Library.Web.Controllers
{
    public class LoginController : Controller
    {
        private readonly ILoginService loginService;

        public LoginController(ILoginService loginService)
        {
            this.loginService = loginService;
        }

        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(LogInViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (loginService.AuthenticateUser(model.Username, model.Password))
                {
                    
                    return RedirectToAction("Welcome", "Home"); 
                }
                else
                {
                    ModelState.AddModelError("", "Invalid username or password");
                }
            }

            
            return View(model);
        }
    }
}
