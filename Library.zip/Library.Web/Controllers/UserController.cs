﻿//using System;
//using System.Text;
//using System.Web.Mvc;
//using Library.Service;
//using Library.Web.ViewModels;

//namespace Library.Web.Controllers
//{
//    public class UserController : Controller
//    {
//        private readonly IUserService userService;

//        public UserController(IUserService userService)
//        {
//            this.userService = userService;
//        }

//        public ActionResult Login()
//        {
//            LogInViewModel logInViewModel = new LogInViewModel();
//            return View(logInViewModel);
//        }

//        [HttpPost]
//        public ActionResult Login(LogInViewModel model)
//        {
//            if (userService.ValidateUser(model.Username, model.Password))
//            {
//                return Content("Login successful");
//            }

//            return Content("Invalid username or password");
//        }

//        public ActionResult Register()
//        {
//            RegisterViewModel registerViewModel = new RegisterViewModel();
//            return View(registerViewModel);
//        }

//        [HttpPost]
//        public ActionResult Register(RegisterViewModel model)
//        {
//            if (ModelState.IsValid)
//            {

//                var newUser = new User
//                {
//                    UserName = model.UserName,
//                    Password = Encoding.UTF8.GetBytes(model.Password),
//                    Email = model.Email,
//                    RegistrationDate = DateTime.Now
//                };


//                userService.RegisterUser(newUser);


//                return Content("Registration successful");
//            }

//            return View(model);
//        }
//    }
//}
using System;
using System.Text;
using System.Web.Mvc;
using Library.Service;
using Library.Web.ViewModels;

namespace Library.Web.Controllers
{
    public class UserController : Controller
    {
        private readonly IUserService userService;

        public UserController(IUserService userService)
        {
            this.userService = userService;
        }

        public ActionResult Login()
        {
            LogInViewModel logInViewModel = new LogInViewModel();
            return View(logInViewModel);
        }

        [HttpPost]
        public ActionResult Login(LogInViewModel model)
        {
            if (userService.ValidateUser(model.Username, model.Password))
            {
                return Content("Login successful");
            }

            return Content("Invalid username or password");
        }

        public ActionResult Register()
        {
            RegisterViewModel registerViewModel = new RegisterViewModel();
            return View(registerViewModel);
        }

        [HttpPost]
        public ActionResult Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var newUser = new User
                {
                    UserName = model.UserName,
                    Email = model.Email,
                    RegistrationDate = DateTime.Now
                };

                // Hash the password before storing it
               // newUser.HashPassword(model.Password);

                userService.RegisterUser(newUser);

                return Content("Registration successful");
            }

            return View(model);
        }
    }
}
