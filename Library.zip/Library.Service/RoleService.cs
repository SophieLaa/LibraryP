﻿//using Library.Data.Repositories;
//using Library.Web;

//namespace Library.Service
//{
//    public class RoleService : IRoleService
//    {
//        private readonly IUserRoleRepository userRoleRepository;

//        public RoleService(IUserRoleRepository userRoleRepository)
//        {
//            this.userRoleRepository = userRoleRepository;
//        }

//        public UserRole GetRoleByTitle(string title)
//        {
//            return userRoleRepository.GetRoleByTitle(title);
//        }

//    }
//}
