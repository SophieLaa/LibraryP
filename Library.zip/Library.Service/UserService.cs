﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using Library.Data.Repositories;
using Library.Web;

namespace Library.Service
{
    public class UserService : IUserService
    {
        private readonly IUsersRepository userRepository;

        public UserService(IUsersRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        public IEnumerable<User> GetUsersInRole(string role)
        {
            var usersInRole = userRepository.GetUsersInRole(role);
            yield return (User)usersInRole;
        }

        public bool ValidateUser(string username, string password)
        {
            var user = userRepository.GetUserByUserName(username);

            if (user != null)
            {
                
                string hashedPassword = GetHashedPassword(password);

                // return VerifyHashedPassword(hashedPassword, user.Password);
                return true;
            }

            return false;
        }

        private bool VerifyHashedPassword(string hashedPassword, byte[] storedPassword)
        {
            byte[] storedHash = ConvertHexStringToBytes(hashedPassword);

            return CompareByteArrays(storedHash, storedPassword);
        }

        private bool CompareByteArrays(byte[] array1, byte[] array2)
        {
            if (array1 == null || array2 == null || array1.Length != array2.Length)
            {
                return false;
            }

            for (int i = 0; i < array1.Length; i++)
            {
                if (array1[i] != array2[i])
                {
                    return false;
                }
            }

            return true;
        }

        private byte[] ConvertHexStringToBytes(string hexString)
        {
            int numberChars = hexString.Length;
            byte[] bytes = new byte[numberChars / 2];
            for (int i = 0; i < numberChars; i += 2)
            {
                bytes[i / 2] = Convert.ToByte(hexString.Substring(i, 2), 16);
            }
            return bytes;
        }


        private string GetHashedPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(password);
                byte[] hash = sha256.ComputeHash(bytes);
                return ConvertToHexString(hash);
            }
        }

        private string ConvertToHexString(byte[] bytes)
        {
            StringBuilder sb = new StringBuilder();
            foreach (byte b in bytes)
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString();
        }

        public void RegisterUser(User newUser)
        {
            throw new NotImplementedException();
        }

        IEnumerable<object> IUserService.GetUsersInRole(string v)
        {
            throw new NotImplementedException();
        }
    }
}   