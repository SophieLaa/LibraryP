﻿//using Library.Web;

//namespace Library.Service
//{
//    public interface IRoleService
//    {
//        UserRole GetRoleByTitle(string title);
//    }
//}
