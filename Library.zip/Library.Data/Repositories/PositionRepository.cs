﻿using Library.Data.Infrastructure;
using Library.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Data.Repositories
{
    public class PositionsRepository : RepositoryBase<Position>, IPositionsRepository
    {
        public PositionsRepository(IDbFactory dbFactory)
            : base(dbFactory) { }

        public Position GetPositionByTitle(string Title)
        {
            var Position = this.DbContext.Positions.Where(c => c.PositionTitle == Title).FirstOrDefault();

            return Position;
        }


        public override void Update(Position entity)
        {
            entity.ChangeDate = DateTime.Now;
            base.Update(entity);
        }
    }

    public interface IPositionsRepository : IRepository<Position>
    {
        Position GetPositionByTitle(string Title);
    }
}

