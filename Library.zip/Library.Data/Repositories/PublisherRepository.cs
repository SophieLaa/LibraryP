﻿using Library.Data.Infrastructure;
using Library.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using Publisher = Library.Web.Publisher;

namespace Library.Data.Repositories
{
    public class PublishersRepository : RepositoryBase<Publisher>, IPublishersRepository
    {
        public PublishersRepository(IDbFactory dbFactory)
            : base(dbFactory) { }

        public Publisher GetPublishersByFirstName(string Name)
        {
            var Publisher = this.DbContext.Publishers.Where(c => c.Name == Name).FirstOrDefault();

            return Publisher;
        }
        public Publisher GetPublishersByEmail(string Email)
        {
            var Publisher = this.DbContext.Publishers.Where(c => c.Email == Email).FirstOrDefault();

            return Publisher;
        }
        public Publisher GetMembersByPhoneNumber(string PhoneNumber)
        {
            var Publisher = this.DbContext.Publishers.Where(c => c.PhoneNumber == PhoneNumber).FirstOrDefault();

            return Publisher;
        }


        public override void Update(Publisher entity)
        {
            entity.ChangeDate = DateTime.Now;
            base.Update(entity);
        }
    }

    public interface IPublishersRepository : IRepository<Publisher>
    {
        Publisher GetPublishersByFirstName(string FirstName);
        Publisher GetPublishersByEmail(string Email);
        Publisher GetMembersByPhoneNumber(string PhoneNumber);

    }
}
