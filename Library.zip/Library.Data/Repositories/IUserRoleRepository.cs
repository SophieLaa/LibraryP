﻿//using Library.Web;

//namespace Library.Data.Repositories
//{
//    public interface IUserRoleRepository
//    {
//        UserRole GetRoleByTitle(string title);
//    }
//}
