﻿namespace Library.Data.Infrastructure
{
    internal class DbContextOptionsBuilder
    {
    }
}